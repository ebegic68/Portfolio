/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <stdexcept>
#include <list>
std::vector<int>Razbrajanje(int N, int M){
    std::vector<int> vektor;
    std::list<int>list;
    int i=1;
    while(i<=N){
        list.push_back(i);
        i++;
    }
    auto t1=list.begin();
    auto t2=list.end();
    if(t1!=t2){
        vektor.push_back(1);
        t1=list.erase(t1);
    }
    for(int i=1; i<=N;i++){
        int br=1;
        while(br<M){
            br++;
            t1++;
            if(t1==t2){
                t1=list.begin();
            }
            
        }
        vektor.push_back(*t1);
        t1=list.erase(t1);
        if(t1==t2)
        t1=list.begin();
        
    }
    return vektor;
    
}
int OdabirKoraka(int N, int M){
    if(N==1 && M==1){
        return 1;
    }
    if(N<=1 || M<=1 || M>N){
        return 0;
    }
    int i=1;
    while(i<100000){
        auto rez=Razbrajanje(N, i);
        if(rez[rez.size()-1]==M){
            return i;
        }
        i++;
    }
    return 0;
}
int main ()
{
    int N,K;
    std::cout<<"Unesite broj distrikta u gradu: ";
    std::cin>>N;
    std::cout<<"Unesite redni broj distrikta u kojem se nalazi restoran: ";
    std::cin>>K;
    int kraj = OdabirKoraka(N, K);
    if(kraj == 0){
        std::cout<<"Nema odgovarajuceg koraka za postizanje zeljenog rezultata."<<std::endl;
    } else {
        std::cout<<"Trazeni korak: "<<kraj<<std::endl;
    }

	return 0;
}